package com.example.filedownload.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.AbstractFileResolvingResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.filedownload.service.EmailService;
import com.itextpdf.text.DocumentException;


@RestController
@RequestMapping("/files")
@CrossOrigin(origins = "http://localhost:5500")
public class fileuploaddownloadController {


	@Autowired
	private EmailService emailService;


	private final String uploadDir = "uploads/";

	@RequestMapping("/hello")
	public String helloworld() {
		return "Hello World";
	}


	@PostMapping("/upload")
	public ResponseEntity<Map<String,String>> uploadfile(@RequestParam("file") MultipartFile file ) throws Exception{
//		Path path= Paths.get(uploadDir + file.getOriginalFilename());
//
//
//		Files.write(path, file.getBytes());
//
//		String filedownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
//				.path("files/download/")
//				.path(file.getOriginalFilename())
//				.toUriString();
//
//		return "File Upload successful! Download URL : <a href='${filedownloadUri}'>" + filedownloadUri +"</a> ";


		 try {
		 String fileName = file.getOriginalFilename();
	        Path filePath = Paths.get(uploadDir + "/" + fileName);
	        Files.copy(file.getInputStream(), filePath);

	        // Respond with the file name
	        Map<String, String> response = new HashMap<>();
	        response.put("message", "File uploaded successfully: " + fileName);
	        response.put("fileName", fileName);
	        System.out.print(response);
	        return ResponseEntity.ok(response);
	    } catch (IOException e) {
	        return ResponseEntity.status(500).body(Map.of("message", "File upload failed: " + e.getMessage()));
	    }


	}



	@GetMapping("/download/{filename}")
	public ResponseEntity<Resource> downloadfile(@PathVariable("filename") String filename) throws Exception{

		Path file = Paths.get(uploadDir).resolve(filename);

		Resource resource =  new org.springframework.core.io.UrlResource(file.toUri());

		if(!((AbstractFileResolvingResource) resource).exists()) {
			throw new Exception("File Not Found");
		}

		return ResponseEntity.ok()
				.contentType(MediaType.APPLICATION_OCTET_STREAM)
				.header(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename= \"" +filename +"\"")
				.body(resource);

	}


	@GetMapping("/Allfiles")
	public List<String> allFiles() throws IOException{

		Path uploadPath = Paths.get(uploadDir);

		return Files.list(uploadPath)
				.filter(Files::isRegularFile)
				.map(path -> path.getFileName().toString())
				.collect(Collectors.toList());

	}


	@GetMapping("/Download-PDF")
	public ResponseEntity<Resource> downloadBargraphPDF(@RequestHeader HttpHeaders headerdata){
		File pdffile = null;

		try {
			pdffile =  PdfGeneratorService.createSamplePdf("sample.pdf");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_PDF);
		header.setContentDispositionFormData("attachment",pdffile.getName());


		return ResponseEntity.ok().headers(header).body(new FileSystemResource(pdffile));
	}


	@GetMapping("/send-simple-email")
	public String sendSimpleEmail(@RequestParam String to,@RequestParam String subject, @RequestParam String message) throws MessagingException, DocumentException, IOException {

			File attachment;
			attachment = PdfGeneratorService.createSamplePdf("sample.pdf");
			emailService.sendSimpleEmail(to, subject, message,attachment);

		return "Email sent successfully";
	}
}
