package com.example.filedownload.controller;


import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class PdfGeneratorService {

    public static File createSamplePdf(String fileName) throws DocumentException, IOException {
        // Specify the file path where the PDF will be temporarily saved
        File pdfFile = new File(System.getProperty("java.io.tmpdir") + File.separator + fileName);

        // Create a new PDF document
        Document document = new Document();
        PdfWriter.getInstance(document, new FileOutputStream(pdfFile));
        document.open();

        // Table generation code (same as the previous example)
        // Add Title
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.BLACK);
        Paragraph title = new Paragraph("Embedded Surcharge*", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);

        document.add(new Paragraph(" ")); // Add space after title

        // Creating Table with 5 Columns
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);
        table.setWidths(new float[]{2f, 2f, 2f, 2f, 2f, 1f}); // Adjust column widths

        // Define fonts for table headers and content
        Font headerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
        Font cellFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);

        // Row 1: Header row with merged cell
        PdfPCell headerCell = new PdfPCell(new Phrase("Embedded Surcharge*", headerFont));
        headerCell.setColspan(2);
        headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        headerCell.setBackgroundColor(BaseColor.DARK_GRAY);
        table.addCell(headerCell);

        // Row 2: Sub-headers
//        table.addCell(createCell("Total Transaction", headerFont, BaseColor.LIGHT_GRAY));
        table.addCell(createCell("Total Shipment", headerFont, BaseColor.LIGHT_GRAY));
        table.addCell(createCell("Current Annual Spent", headerFont, BaseColor.LIGHT_GRAY));
        table.addCell(createCell("Projected Annual Spent", headerFont, BaseColor.LIGHT_GRAY));
        table.addCell(createCell("Difference", headerFont, BaseColor.LIGHT_GRAY));

        // Row 3




        table.addCell(createCell("Total Transaction", headerFont, BaseColor.LIGHT_GRAY));

        PdfPTable nestedTable = new PdfPTable(1); // 2 columns in the nested table
        nestedTable.setWidthPercentage(100);
        nestedTable.addCell(createCell("Transaction", cellFont));
        nestedTable.addCell(createCell("Embedded Surcharge", cellFont));
        PdfPCell nestedTableCell = new PdfPCell();
        nestedTableCell.addElement(nestedTable);
        table.addCell(nestedTableCell);


        PdfPTable nestedTable1 = new PdfPTable(1); // 2 columns in the nested table
        nestedTable1.setWidthPercentage(100);
        nestedTable1.setSpacingBefore(0);
        nestedTable1.addCell(createCell("59", cellFont));
        nestedTable1.addCell(createCell("20", cellFont));
        PdfPCell nestedTableCell1 = new PdfPCell();
        nestedTableCell1.addElement(nestedTable1);
        table.addCell(nestedTableCell1);



        PdfPTable nestedTable2 = new PdfPTable(1); // 2 columns in the nested table
        nestedTable2.setWidthPercentage(100);
        nestedTable2.setSpacingBefore(0);
        nestedTable2.addCell(createCell("9902.01", cellFont));
        nestedTable2.addCell(createCell("n/a", cellFont));
        PdfPCell nestedTableCell2 = new PdfPCell();
        nestedTableCell2.setBorder(Rectangle.NO_BORDER);
        nestedTableCell2.addElement(nestedTable2);
        table.addCell(nestedTableCell2);


        PdfPTable nestedTable3 = new PdfPTable(1); // 2 columns in the nested table
        nestedTable3.setWidthPercentage(100);
        nestedTable3.setSpacingBefore(0);
        nestedTable3.addCell(createCell("9500", cellFont));
        nestedTable3.addCell(createCell("1015.02", cellFont));
        PdfPCell nestedTableCell3 = new PdfPCell();
        nestedTableCell3.addElement(nestedTable3);
        table.addCell(nestedTableCell3);


        PdfPTable nestedTable4 = new PdfPTable(1); // 2 columns in the nested table
        nestedTable4.setWidthPercentage(100);
        nestedTable4.setSpacingBefore(0);
        nestedTable4.addCell(createCell("-402.01", cellFont));
        nestedTable4.addCell(createCell(" ", cellFont));
        PdfPCell nestedTableCell4 = new PdfPCell();
        nestedTableCell4.addElement(nestedTable4);
        table.addCell(nestedTableCell4);

        // Row 5: Surcharge Removed & Kept


        table.addCell(createCell("Surcharge ", headerFont, BaseColor.LIGHT_GRAY));

        PdfPTable nested_Table = new PdfPTable(1); // 2 columns in the nested table
        nested_Table.setWidthPercentage(100);
        nested_Table.addCell(createCell("Removed*", cellFont));
        nested_Table.addCell(createCell("Kept", cellFont));
        PdfPCell nested_TableCell = new PdfPCell();
        nested_TableCell.addElement(nested_Table);
        table.addCell(nested_TableCell);


        PdfPTable nested_Table1 = new PdfPTable(1); // 2 columns in the nested table
        nested_Table1.setWidthPercentage(100);
        nested_Table1.setSpacingBefore(0);
        nested_Table1.addCell(createCell("59", cellFont));
        nested_Table1.addCell(createCell("20", cellFont));
        PdfPCell nested_TableCell1 = new PdfPCell();
        nested_TableCell1.addElement(nested_Table1);
        table.addCell(nested_TableCell1);



        PdfPTable nested_Table2 = new PdfPTable(1); // 2 columns in the nested table
        nested_Table2.setWidthPercentage(100);
        nested_Table2.setSpacingBefore(0);
        nested_Table2.addCell(createCell("9902.01", cellFont));
        nested_Table2.addCell(createCell("n/a", cellFont));
        PdfPCell nested_TableCell2 = new PdfPCell();
        nested_TableCell2.setBorder(Rectangle.NO_BORDER);
        nested_TableCell2.addElement(nested_Table2);
        table.addCell(nested_TableCell2);


        PdfPTable nested_Table3 = new PdfPTable(1); // 2 columns in the nested table
        nested_Table3.setWidthPercentage(100);
        nested_Table3.setSpacingBefore(0);
        nested_Table3.addCell(createCell("9500", cellFont));
        nested_Table3.addCell(createCell("1015.02", cellFont));
        PdfPCell nested_TableCell3 = new PdfPCell();
        nested_TableCell3.addElement(nested_Table3);
        table.addCell(nested_TableCell3);


        PdfPTable nested_Table4 = new PdfPTable(1); // 2 columns in the nested table
        nested_Table4.setWidthPercentage(100);
        nested_Table4.setSpacingBefore(0);
        nested_Table4.addCell(createCell("-402.01", cellFont));
        nested_Table4.addCell(createCell(" ", cellFont));
        PdfPCell nested_TableCell4 = new PdfPCell();
        nested_TableCell4.addElement(nested_Table4);
        table.addCell(nested_TableCell4);







        // Row 6: Total
        PdfPCell totalcell = new PdfPCell(new Phrase("Total", headerFont));
        totalcell.setColspan(2);
        totalcell.setHorizontalAlignment(Element.ALIGN_CENTER);
        totalcell.setBackgroundColor(BaseColor.DARK_GRAY);
        table.addCell(totalcell);
        table.addCell(createCell("59", cellFont));
        table.addCell(createCell("14702.01", cellFont));
        table.addCell(createCell("13015.02", cellFont));
        table.addCell(createCell("-1686.99", cellFont));


        PdfPCell Notecell = new PdfPCell(new Phrase("Note", headerFont));
        Notecell.setColspan(2);
        Notecell.setHorizontalAlignment(Element.ANCHOR);
        Notecell.setBackgroundColor(BaseColor.DARK_GRAY);
        table.addCell(Notecell);


        PdfPCell messagecell = new PdfPCell(new Phrase("Some of the TNT surcharges which are not avilable in FedEx got taken into consideration into the transaction cost, the total amount of \"projected Annual Spent\" of \"embedded surcharge\" and the \"kept surcharge, are the total new amount of migrated TNT surcharge The \"removed surcharge\" is previous TNT surcharge(s) not available in FedEx, those surcharges will not be charged after migrating to FedEx", headerFont));
        messagecell.setColspan(4);
        messagecell.setHorizontalAlignment(Element.ALIGN_LEFT);
        messagecell.setBackgroundColor(BaseColor.DARK_GRAY);
        table.addCell(messagecell);




        // Add table to the document
        document.add(table);

        // Add notes section
        Font notesFont = new Font(Font.FontFamily.HELVETICA, 8, Font.ITALIC, BaseColor.BLACK);
        Paragraph notes = new Paragraph(
            "*Notes: Some of the TNT surcharges which are not available in FedEx got taken into consideration into the transaction cost...",
            notesFont);
        document.add(notes);

        // Close document
        document.close();

        return pdfFile; // Return the File object pointing to the created PDF
    }

    private static PdfPCell createCell(String content, Font font) {
        return createCell(content, font, BaseColor.WHITE);
    }

    private static PdfPCell createCell(String content, Font font, BaseColor backgroundColor) {
        PdfPCell cell = new PdfPCell(new Phrase(content, font));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBackgroundColor(backgroundColor);
        return cell;
    }
}
