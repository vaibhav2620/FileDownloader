package com.example.filedownload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileDownloaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileDownloaderApplication.class, args);
	}

}
