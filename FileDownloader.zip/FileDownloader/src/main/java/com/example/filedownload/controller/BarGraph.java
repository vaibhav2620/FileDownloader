package com.example.filedownload.controller;


/**
 * Creates a bar graph of the rainfall last year in both Seattle and Philadelphia each month
 *
 * Landon
 * 2/11/2020
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class BarGraph {
    private JFrame frame;

    public BarGraph() {
        frame = new JFrame("Bar Graph");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setPreferredSize(frame.getSize());
        frame.add(new DrawBars(frame.getSize()));
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String... argv) {
        new BarGraph();
    }

    public static class DrawBars extends JPanel  implements MouseListener {
        /*
         * Declare Instance Variables Here
         */
        private int x = 20;
        private int y = 200;
        private double[] phila =
            {2.85,6.02,4.74,3.94,5.21,3.34,3.06,4.11,8.35,3.08,9.03,6.38};
        private double[] seattle =
            {8.12,2.16,2.44,5.69,0.12,0.63,0.05,0.2,0.98,3.78,5.42,6.08};


        public DrawBars(Dimension dimension) {
            setSize(dimension);
            setPreferredSize(dimension);
            addMouseListener(this);

        }

        @Override
        public void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D)g;  //g2 is the graphics object that we need to use
                                            //to draw things to the screen
            Dimension d = getSize();
            //create a background
            g2.setColor(Color.white);
            g2.fillRect(0, 0, d.width, d.height);


            Color purple = new Color(102,0, 102);
            Color green = new Color(10,255, 102);

            for(int i = 0; i < phila.length; i++){
                g2.setColor(purple);
                g2.fillRect(i*30, 360-(int)(phila[i]*35),12,(int)(phila[i]*70));
            }
            for(int i = 0; i < seattle.length; i++){
                g2.setColor(green);
                g2.fillRect(i*30 + 15, 360-(int)(seattle[i]*35),12,(int)(seattle[i]*70));
            }

            g2.setColor(purple);
            g2.setFont (new Font("Arial", Font.PLAIN, 20));
            g2.drawString("Philadelphia" ,  10,30);//text to display, x and y coordinates
            g2.setColor(green);
            g2.drawString("Seattle" ,  200,30);

        }
        public void mousePressed(MouseEvent e) {
            x = e.getX();
            y = e.getY();

            repaint();
        }

        public void mouseReleased(MouseEvent e) {}

        public void mouseEntered(MouseEvent e) {}

        public void mouseExited(MouseEvent e) {}

        public void mouseClicked(MouseEvent e) {}
    }
}
