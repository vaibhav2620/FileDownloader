package com.example.filedownload.service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.*;
import org.springframework.stereotype.Service;

import java.io.File;
@Service
public class EmailService {

	@Autowired
	private JavaMailSender javamailsender;

	public void sendSimpleEmail(String to, String subject, String Message,File Attachment) throws MessagingException {

		 jakarta.mail.internet.MimeMessage message = javamailsender.createMimeMessage();

		 MimeMessageHelper helper;
			try {
				   helper = new MimeMessageHelper(message, true);
					helper.setTo(to);
					helper.setSubject(subject);
					helper.setText(Message);
					helper.setFrom("vmistry2620@gmail.com");

					helper.addAttachment(Attachment.getName(), Attachment);


			} catch (jakarta.mail.MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // 'true' enables multipart mode




		javamailsender.send(message);
	}

}
