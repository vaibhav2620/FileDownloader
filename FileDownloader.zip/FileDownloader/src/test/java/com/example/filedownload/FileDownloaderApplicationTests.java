package com.example.filedownload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileDownloaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
